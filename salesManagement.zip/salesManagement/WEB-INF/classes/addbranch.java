import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import javax.swing.*;


public class addproduct extends HttpServlet {
  
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      HttpSession session = request.getSession(false);
	 if(session!=null)
	 {
	response.setContentType("text/html");
	PrintWriter out = response.getWriter();
	
	String bid=request.getParameter("id");
   String admin=request.getParameter("admin");
    String location=request.getParameter("location");
 
    out.println("<html >");
out.println("<head>");
  out.println("<title>Title</title>");
	 
out.println("</head>");


out.println("<link href='see.css'rel='stylesheet'>");

out.println("<body  background='images/bg4.jpg' >");

out.println("<div style='width: 1330px;height: 100px'>");

out.println("<a href='headoffice.html'> <button  style='margin-left:40%;background-color:green;text-align: center; cursor: pointer;font-size: 16px;padding: 15px 25px;  color: white;'>Back to head-office Panel</button></a>");
out.println("</div>");

out.println("<br><br><br><br><br>");


    try{

    Class.forName("com.mysql.jdbc.Driver");
    String url = "jdbc:mysql://127.0.0.1/Sales";
    Connection con=DriverManager.getConnection(url,"root","");
    Statement st=con.createStatement();
	
	 String query1 = "select * from branches where bid="+bid+"; ";
	  ResultSet rs = st.executeQuery( query1 );

     out.println("<div align='center' style='border: 2px solid #1E0A05;margin-left:270px; width: 800px;height: 100px;background-image: url('images/bg5.jpg');'>");
     
	  if(rs.next())
	  {
		 
            out.println("choose a unique Product ID");
			out.println("</div>");
	     
	  }
	  else 
	  {
		  query1 = "insert into branches(bid,admin,location) values("+bid+",'"+admin+"', '"+location+"')";
	      int n = st.executeUpdate( query1 );
		  if(n > 0)
		  {
			  out.println("<h1>Branch added</h1>");
			  out.println("</div>");
		  }
		  else
		  {
			   out.println("<h1>Branch could not be added</h1>");
			  out.println("</div>");
		  }
	  }

     out.println("</body></html>");

		   st.close();
           con.close();

    }catch(Exception e){

      out.println(e);
    }
}
else{
		 response.sendRedirect("login.html");
	 }

  }

}

	
	
	
	
	
	
	
	