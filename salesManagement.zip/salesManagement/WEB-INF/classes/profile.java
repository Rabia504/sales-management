import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;


public class profile extends HttpServlet {

  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    HttpSession session = request.getSession(false);
	 if(session!=null)
	 {
		int customid=0;
	if(session.getAttribute("cid") == null){
	response.sendRedirect("home.java");
    }
   else{
    customid = (int) session.getAttribute("cid");}
	 
		 
    PrintWriter out = response.getWriter();
	 
    out.println("<html>");
	 out.println("<head><title>profile</title>");
	out.println("<script >");
out.println("function validate()");
out.println("{");
out.println("if(document.user.newpwd.value!=document.user.cpwd.value)");
	out.println("{");
	 out.println("document.getElementById('cerror').innerHTML='*Password and Confirm Password donot match';");
			out.println("document.user.cpwd.focus();");
			out.println("return false;");
	out.println("}	");
out.println("return true;");
out.println("}");
	out.println("</script>	");
	
	out.println("</head>");
   
	out.println("<link href='see.css'rel='stylesheet'>");
out.println("<link href='form.css'rel='stylesheet'>");

 out.println("<body align='center' background='images/bg4.jpg' style='background-size:100% 100%'>");

out.println("<div style='width: 1330px;height: 100px'>");
      out.println("<ul class='nav-area'style='background:linear-gradient(rgba(0,0,0,0.6),rgba(0,0,0,0.6));height: 50px; float:center;margin-right:30%;'>");

            out.println("<li style='margin-top:20px'><a href='http://localhost:8080/project/home'>HOME</a></li>");
            out.println("<li style='margin-top:20px'><a href='http://localhost:8080/project/menu'>BRANCHES</a></li>");
            out.println("<li style='margin-top:20px'><a href='services.html'>SERVICES</a></li>");
			out.println("<li style='margin-top:20px'><a href='http://localhost:8080/project/customreservation'>Update Reservation</a></li>");
			out.println("<li style='margin-top:20px'><a href='http://localhost:8080/project/logout'>LOGOUT</a></li>");
	   out.println("</ul>");
		
out.println("</div>");


    try{
    Class.forName("com.mysql.jdbc.Driver");

    String url = "jdbc:mysql://127.0.0.1/Sales";

    Connection con=DriverManager.getConnection(url,"root","");

    Statement st=con.createStatement();
    
     String query="Select * from customers where cid="+customid+" ";
   
     ResultSet rs = st.executeQuery( query );
   
     if(rs.next()){

      String email = rs.getString("email");
	  String fname = rs.getString("fname");
	  String lname = rs.getString("lname");
	  String city = rs.getString("city");
	  String address = rs.getString("address");
	  String phone = rs.getString("phone");
	  String gender = rs.getString("gender");
	  
	  
	   out.println("<form name=user method='GET' align=center action='editprofile' onsubmit='return validate()'>");
  out.println("<h1 align='center'>Customer Profile<h1>");
 out.println("<table align=center>");
         
		 
	     if(session.getAttribute("newpwd") == null){
	      out.println("    <tr>");
     out.println(" </tr>");
         }
         else  if((int)session.getAttribute("newpwd") == 2){
			   out.println("    <tr>");
	 out.println("     <td  align='center'><h2> password changed successfully<h2></td> ");
      out.println(" </tr>");
	   session.setAttribute("newpwd", null);
        }
		 else  if((int)session.getAttribute("newpwd") == 1){
			   out.println("    <tr>");
	 out.println("     <td  align='center'><h2> password could not be updated<h2></td> ");
      out.println(" </tr>");
	   session.setAttribute("newpwd", null);
        }
		if(session.getAttribute("editprofile") == null){
	      out.println("    <tr>");
     out.println(" </tr>");
         }
	    else if((int)session.getAttribute("editprofile") == 2)
	   {
		    out.println("    <tr>");
	 out.println("     <td  align='center'><h2>Profile updated successfully<h2></td> ");
      out.println(" </tr>");
	   session.setAttribute("newpwd", null);
	   }
		 
		 
		 
	  	out.println("   <tr> ");
	     out.println("<td  align='right'>Email</td> ");
	     out.println("<td ><input  name='email' type='email' value='"+email+"' readonly></td>	");
	  out.println(" </tr> ");
	  out.println(" <br><br><br><br>");	   
	     out.println("<tr> ");
	    out.println(" <td  align='right'>First Name </td> ");
	    out.println(" <td ><input type='text' name='fname' value='"+fname+"' ></td> ");
         
		  	     out.println("<td  align='right'>Last Name </td> ");
	     out.println("<td ><input type='text' name='lname' value='"+lname+"' ></td> ");
        
	   out.println("</tr>");
		out.println("   <tr> ");
		 
	     out.println("<td  align='right'>Gender</td> ");
	     out.println("<td ><input  name='gender' type='text' value='"+gender+"' ></td>	");
	  out.println(" </tr> ");

       out.println("   <tr> ");
	     out.println("<td  align='right'>City</td> ");
	     out.println("<td ><input  name='city' type='text' value='"+city+"' ></td>	");
	  out.println(" </tr> ");
	  
	    out.println("   <tr> ");
	     out.println("<td  align='right'>Address</td> ");
	     out.println("<td ><input  name='address' type='text' value='"+address+"'></td>	");
	  out.println(" </tr> ");
	    out.println("   <tr> ");
	     out.println("<td  align='right'>Phone</td> ");
	     out.println("<td ><input  name='phone' type='number' value="+phone+" ></td>");	
	  out.println(" </tr> ");
	  out.println(" <tr> </tr>  ");
	  
	 out.println("<tr>");
	     out.println("<td ></td> ");
	     out.println("<td ><b><input type='submit' value='Edit Profile'/></b></td> ");
		  out.println("</tr> ");
	   out.println("</table>");	
	   out.println(" <br><br><br><br>");	
	   out.println("<h1 align='center'>Edit password<h1>");
	   out.println("<table align=center>");
         
	  	out.println("   <tr> ");
	     out.println("<td  align='right'>Enter old password</td> ");
	     out.println("<td ><input  name='pwd' type='password' ></td>	");
	  out.println(" </tr> ");
	  out.println("   <tr> ");
	     out.println("<td  align='right'>Enter new password</td> ");
	     out.println("<td ><input  name='newpwd' type='password' ></td>	");
	  out.println(" </tr> ");
	  out.println("   <tr> ");
	     out.println("<td  align='right'>Confirm new password</td> ");
	     out.println("<td ><input  name='cpwd' type='password' ></td>	");
		  out.println("<td id='cerror' style='color:red'> </td> ");
	  out.println(" </tr> ");
	  out.println("   <tr> ");
	  out.println("<td ></td> ");
	   out.println("<td ><b><input type='submit' value='Edit Password' ></b></td> ");
	     out.println(" </tr> ");
	 
 out.println("</table>");
out.println("</form>");

	  
	  
	  
	 }
	 
	 
     out.println("</body></html>");
	//Thread.sleep(4000);
    // response.sendRedirect("menu.java");
	

		   st.close();
           con.close();

    }catch(Exception e){

      out.println(e);
    }
	 }
	 else{
		 response.sendRedirect("login.html");
	 }

  }

}
