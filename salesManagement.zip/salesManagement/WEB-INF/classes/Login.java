import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;


public class Login extends HttpServlet {

  //Process the HTTP Get request
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    
    PrintWriter out = response.getWriter();

    String email=request.getParameter("email");
	String password=request.getParameter("pwd");
    String cookie=request.getParameter("remember");
	// HttpSession session = request.getSession();
	 
	 
    out.println("<html>");
    out.println("<head><title>Response</title></head>");
    out.println("<body bgcolor=\"#ffffff\">");


    try{
    Class.forName("com.mysql.jdbc.Driver");

    String url = "jdbc:mysql://127.0.0.1/restaurant";

    Connection con=DriverManager.getConnection(url,"root","rabbit123");

    Statement st=con.createStatement();
    
     String query="Select * from customers where email='"+email+"' and password='"+password+"' ";
   
     ResultSet rs = st.executeQuery( query );
   
     if(rs.next()){
		 //if(cookie!=null)
		 //{
		 //Cookie c=new Cookie(email,password);
    // c.setMaxAge(10*24*60*60);
    // response.addCookie(c);
		// }
		 //String status = rs.getString("usertype");
		 
		 HttpSession session = request.getSession();
		 session.setMaxInactiveInterval(1*24*60*60);
		 int cid = rs.getInt("cid");
		 String cname = rs.getString("name");
		 session.setAttribute("cid", cid);
		 session.setAttribute("cname", cname);
		 
	   response.sendRedirect("http://localhost:8080/salesmanagement/home");
          
	  }
	  else
	  {
		   String query="Select * from admin where id='"+email+"' and password='"+password+"' ";
		   ResultSet rs = st.executeQuery( query );
		   if(rs.next())
		   {
			   int id = rs.getInt("id");
			   String name = rs.getString("name");
			   session.setAttribute("cid", id);
			   session.setAttribute("cname", name);
			   response.sendRedirect("headoffice.html");
		   }
		    else
		   {
			   out.println("<h1>login not successful</h1>");
           }
	  }
    


out.println("</body></html>");
           st.close();
           con.close();

    }catch(Exception e){

      out.println(e);
    }

  }

}
