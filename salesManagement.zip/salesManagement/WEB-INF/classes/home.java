import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import javax.swing.*;


public class home extends HttpServlet {
  
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  
    
	response.setContentType("text/html");
    //response.setContentType("image/jpeg");
	PrintWriter out = response.getWriter();
out.println("<html >");
out.println("<head>");
    out.println("<title>home</title>");	
out.println("</head>");

 out.println("<link rel='stylesheet' type='text/css' href='https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css'> ");
 out.println("<link href='https://unpkg.com/aos@2.3.1/dist/aos.css' rel='stylesheet'>");
out.println("<link href='see.css'rel='stylesheet'>");

out.println("<body align='center' background='images/bg8.jpg' style='background-size:100% 100%'>");

out.println("<div style='width: 1360px;height: 800px; background:url(images/Sales.jpeg);background-repeat:no-repeat;background-size:100% 90%;'class='cafe'>");
   out.println("<header class='dropdown'>");

       out.println(" <ul class='nav-area'>");

            out.println("<li><a href='http://localhost:8080/project/home'>HOME</a></li>");
            out.println("<li><a href='http://localhost:8080/project/menu'>BRANCHES</a></li>");
            out.println("<li><a href='services.html'>SERVICES</a></li>");
            	HttpSession session = request.getSession(false);
	 if(session==null)
	 {
            out.println("<li style='margin-top:20px'><a href='register.html'>REGISTER</a></li>");
            out.println("<li style='margin-top:20px'><a href='login.html'>LOGIN</a></li>");
     }
	 else
	 {
		 String customname=null;
	     if(session.getAttribute("cid") == null){
	     response.sendRedirect("home.java");
         }
         else{
         customname = (String) session.getAttribute("cname");}
	
		 out.println("<li style='margin-top:20px'><a href='http://localhost:8080/project/profile'>Edit profile</a></li>");
            out.println("<li style='margin-top:20px'><a href='http://localhost:8080/project/customreservation'>Make Order</a></li>");
          
			out.println("<li style='margin-top:20px'><a href='http://localhost:8080/project/logout'>Logout</a></li>");
	 }
        out.println("</ul>");

    out.println("<div class='welcome-text'>");
       out.println(" <h1>JK COMPANY</h1>");
        out.println(" <a href='http://localhost:8080/project/menu' class='btn'>View Products</a>");
        out.println("<a href='http://localhost:8080/project/resvform' class='btn'>Purchase Product</a>");
    out.println("</div>");
    out.println("</header>");


out.println("</div>");


 out.println(" <style>");
out.println("button{");
	 out.println("width: 100%;");
	 out.println("font-size: 30px;");
	 out.println("height: 15%;");
  out.println("border: 2px solid #1E0A05;");
   out.println("background-color:#FD724F;");
out.println("}");
out.println("button:hover {");
 out.println(" background-color: #E8532E;");
out.println("}");
out.println(" </style>");


 out.println("<section class='wt-section bg-light' id='about'>");
   out.println(" <div class='container'>");
	out.println("	<div class='row justify-content-md-center text-center pb-lg-4 mb-lg-5 mb-4'>");
   out.println("       <div class='col-md-8 text-center w-md-50 mx-auto mb-0'>");
    out.println("        <h2 class='b-md-2'>About Us</h2>");
     out.println("       <p class='lead text-muted'>Online Sales Management System</p>");
     out.println("</div>");
	out.println("</div>");
     out.println("   <div class='row justify-content-between align-items-center' >");
	out.println("	  <div class='col-md-5'>");
      out.println("          <img src='images/Sales.jpeg' width='90%' class='rounded-md' alt=''>");
     out.println("</div>");
       out.println("     <div class='col-md-7'> ");
       out.println("         <h3 class='mb-4'>Who We Are</h3>");
       out.println(" <p class='text-muted'>The JK Company owns many branches around the island. Head-office, each branch owns separate vehicles for the product transport service</p>");
      out.println("</div>");
          
      out.println("</div>");
  out.println("</div>");
out.println("</section>");



out.println("<br>");
 //footer
 
 out.println("<div align='center' class='col-md-5'>");
  
 out.println(" <div class='row contact-info'>");
		out.println("<div class='col-md-12'>");
		out.println("<div class='bg-white p-4 d-flex mb-md-4 border rounded-md' >");
           out.println(" <i class='fa fa-address-book mt-md-1 text-primary pr-4'></i>");
			out.println("<div class='text-left'>");
			out.println("<h6 class='mb-2'>Address</h6>");
			out.println("<p class='text-muted'>JK Island</p> ");
			out.println("</div>");
              out.println("</div>");
				
			out.println("<div class='bg-white p-4 d-flex mb-md-4 border rounded-md' >");
             out.println(" <i class='fas fa-envelope-open mt-md-1 text-primary pr-4'></i>");
			out.println("<div class='text-left'>");
			out.println("  <h3 class='h5'>Email</h3>");
            out.println("<p class='mb-0'>mail@jk.com</p>");
				out.println("</div>");
               out.println("</div>");
				
			out.println("	<div class='bg-white p-4 d-flex mb-md-4 border rounded-md' >");
             out.println("<i class='fa fa-phone mt-md-1 text-primary pr-4'></i>  "); 
			out.println("<div class='text-left'>");
			out.println(" <h3 class='h5'>Phone Number</h3>");
            out.println("<p class='mb-0'>1-111-222-3333</p>");
					out.println("</div>");
              out.println("</div>");	 
			out.println("</div>");
        out.println("</div>");
 out.println("</div>");
 
out.println("<br><br>");

out.println("</body>");
out.println("</html>");

    }
  }

