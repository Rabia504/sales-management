import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import javax.swing.*;


public class Register extends HttpServlet {
  
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  
	response.setContentType("text/html");
    
	PrintWriter out = response.getWriter();

    String email=request.getParameter("email");
    String password=request.getParameter("pwd");
	String fname=request.getParameter("fname");
	String lname=request.getParameter("lname");
	String gender=request.getParameter("gender");
	String city=request.getParameter("city");
	String address=request.getParameter("address");
	String phone=request.getParameter("phone");
	String name=fname+lname;
	System.out.println("email " + email);
	System.out.println("password " + password);
   
    out.println("<html>");
    out.println("<head><title>Response</title></head>");
    out.println("<body bgcolor=\"#ffffff\">");

    try{

    Class.forName("com.mysql.jdbc.Driver");
    String url = "jdbc:mysql://127.0.0.1/restaurant";
    Connection con=DriverManager.getConnection(url,"root","rabbit123");

    Statement st=con.createStatement();

     
     String query = "INSERT INTO customers(email,password,name,gender,city,address,phone)VALUES('"+ email + "','" + password+ "','" + name+ "','" + gender+ "','" + city+ "','" + address+ "','" + phone+ "') ";

     System.out.println(query);

      int rs = 0; 
	 rs=st.executeUpdate( query );

     if(rs==1){	
	  response.sendRedirect("login.html");
	 //out.println("<h1>Account Created Successfully</h1>"); 	
	 }
	else{	
	
	out.println("<h1>account could not be created</h1>"); 	
	}

     out.println("</body></html>");

           st.close();
           con.close();

    }catch(Exception e){

      out.println(e);
    }

  }

}
