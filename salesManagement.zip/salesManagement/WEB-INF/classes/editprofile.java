import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;



public class editprofile extends HttpServlet {

  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    HttpSession session = request.getSession(false);
	 if(session!=null)
	 {
		int customid=0;
	if(session.getAttribute("cid") == null){
	response.sendRedirect("home.java");
    }
   else{
    customid = (int) session.getAttribute("cid");}
	
	PrintWriter out = response.getWriter();
	
	String email=request.getParameter("email");
	String city=request.getParameter("city");
    String address=request.getParameter("address");
	 String phone=request.getParameter("phone");
	 String newpwd=request.getParameter("newpwd");
	 String oldpwd=request.getParameter("pwd");
	
	  try{
    Class.forName("com.mysql.jdbc.Driver");

    String url = "jdbc:mysql://127.0.0.1/Sales";

    Connection con=DriverManager.getConnection(url,"root","");

    Statement st=con.createStatement();
    
     String query="Select * from customers where cid="+customid+" ";
   
     ResultSet rs = st.executeQuery( query );
   
     if(rs.next()){
	 
	  String password = rs.getString("pwd");
	  if(password.equals(oldpwd) && newpwd!=null)
	  {
	  query="UPDATE customers SET email ='"+email+"',password ='"+newpwd+"', phone = '"+phone+"',address='"+address+"' WHERE cid="+customid+"";
	  //session.setAttribute("editprofile", 2);
	  session.setAttribute("newpwd", 2);
	  }
	  else if(!(password.equals(oldpwd)) && oldpwd!=null && newpwd!=null){
		  query="UPDATE customers SET email ='"+email+"', phone = '"+phone+"',address='"+address+"' WHERE cid="+customid+"";
	       session.setAttribute("editprofile", 2);
		  session.setAttribute("newpwd", 1);
	  }
	  else {
		  query="UPDATE customers SET email ='"+email+"', phone = '"+phone+"',address='"+address+"' WHERE cid="+customid+"";
	       session.setAttribute("editprofile", 2);
	  }
	  int n=st.executeUpdate( query );
	  if(n>0)
	  {
		  RequestDispatcher rd = request.getRequestDispatcher("/profile");
	   rd.forward(request,response);  
	  }
	  else
	  {
		  out.println("Profile not updated");
	  }
		  
	 } 
		
	 
	 st.close();
           con.close();

    }catch(Exception e){

      out.println(e);
    }
	 }
	 else{
		 response.sendRedirect("login.html");
	 }

  }

}
