import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;



public class logout extends HttpServlet {

  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    HttpSession session = request.getSession(false);
	 if(session!=null)
	 {
		session.invalidate();
		RequestDispatcher rd = request.getRequestDispatcher("/home");
	   rd.forward(request,response);
	 }
	 else{
		 response.sendRedirect("login.html");
	 }

  }

}
